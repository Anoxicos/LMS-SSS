<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { Head, Link } from '@inertiajs/vue3'

import Layout from '@/Layouts/main.vue'
import PageHeader from '@/Components/page-header.vue'

import '../course-viewer.css'

const props = defineProps({
  course: {
    type: Object,
    required: true,
  },
})

const scormFrame = ref(null)
const scormData = ref({})

const courseImage = computed(() => {
  if (props.course.image_url) {
    return props.course.image_url
  }

  if (props.course.image) {
    return `/storage/${props.course.image}`
  }

  return null
})

const courseInitials = computed(() => {
  return String(props.course.title || 'SC')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word.charAt(0).toUpperCase())
    .join('')
})

const formattedCreatedAt = computed(() => {
  if (!props.course.created_at) return '-'

  return new Date(props.course.created_at).toLocaleDateString('en-GB', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  })
})

const formattedPrice = computed(() => {
  const price = Number(props.course.price || 0)

  if (props.course.type !== 'paid' || price === 0) {
    return 'Free'
  }

  return `${price.toFixed(2)} ${props.course.currency || ''}`
})

const courseStatusLabel = computed(() => {
  return props.course.is_published ? 'Published' : 'Draft'
})

const scormTitle = computed(() => {
  return props.course.scorm_title || props.course.title || 'SCORM Course'
})

const scormVersion = computed(() => {
  return props.course.scorm_version || 'SCORM Package'
})

const createScormApi = () => {
  return {
    LMSInitialize: () => {
      return 'true'
    },

    LMSFinish: () => {
      return 'true'
    },

    LMSGetValue: (key) => {
      return scormData.value[key] || ''
    },

    LMSSetValue: (key, value) => {
      scormData.value[key] = value
      return 'true'
    },

    LMSCommit: () => {
      return 'true'
    },

    LMSGetLastError: () => {
      return '0'
    },

    LMSGetErrorString: () => {
      return ''
    },

    LMSGetDiagnostic: () => {
      return ''
    },
  }
}

onMounted(() => {
  window.API = createScormApi()
})

onBeforeUnmount(() => {
  delete window.API
})
</script>

<template>
  <Layout>
    <Head :title="course.title" />
    <PageHeader title="SCORM Course" pageTitle="Courses" />

    <div class="course-viewer-page">
      <div class="viewer-hero pro-hero">
        <div class="viewer-hero-main">
          <div class="viewer-course-cover">
            <img
              v-if="courseImage"
              :src="courseImage"
              :alt="course.title"
              draggable="false"
              @contextmenu.prevent
            />

            <div v-else class="viewer-course-cover-fallback">
              {{ courseInitials }}
            </div>
          </div>

          <div class="viewer-hero-content">
            <div class="viewer-badge-row">
              <span class="viewer-badge badge-warning">
                <i class="ri-code-box-line"></i>
                SCORM
              </span>

              <span
                class="viewer-badge"
                :class="course.is_published ? 'badge-success' : 'badge-warning'"
              >
                <i :class="course.is_published ? 'ri-checkbox-circle-line' : 'ri-draft-line'"></i>
                {{ courseStatusLabel }}
              </span>

              <span class="viewer-badge badge-info">
                <i class="ri-stack-line"></i>
                {{ scormVersion }}
              </span>

              <span class="viewer-badge badge-date">
                <i class="ri-calendar-line"></i>
                {{ formattedCreatedAt }}
              </span>
            </div>

            <h2>{{ course.title }}</h2>

            <p>
              {{ course.description || 'No description available for this SCORM course.' }}
            </p>

            <div class="course-info-grid">
              <div class="course-info-item">
                <i class="ri-graduation-cap-line"></i>

                <div>
                  <span>Type</span>
                  <strong>{{ course.type || '-' }}</strong>
                </div>
              </div>

              <div class="course-info-item">
                <i class="ri-computer-line"></i>

                <div>
                  <span>Training</span>
                  <strong>{{ course.training_type || '-' }}</strong>
                </div>
              </div>

              <div class="course-info-item">
                <i class="ri-bar-chart-line"></i>

                <div>
                  <span>Level</span>
                  <strong>{{ course.skill_level || '-' }}</strong>
                </div>
              </div>

              <div class="course-info-item">
                <i class="ri-translate-2"></i>

                <div>
                  <span>Language</span>
                  <strong>{{ course.language || '-' }}</strong>
                </div>
              </div>

              <div class="course-info-item">
                <i class="ri-money-dollar-circle-line"></i>

                <div>
                  <span>Price</span>
                  <strong>{{ formattedPrice }}</strong>
                </div>
              </div>

              <div class="course-info-item stat-info-item">
                <i class="ri-code-box-line"></i>

                <div>
                  <span>Content</span>
                  <strong>SCORM</strong>
                </div>
              </div>

              <div class="course-info-item stat-info-item">
                <i class="ri-file-zip-line"></i>

                <div>
                  <span>Package</span>
                  <strong>{{ course.scorm_zip_path ? 'Uploaded' : 'Missing' }}</strong>
                </div>
              </div>

              <div class="course-info-item stat-info-item">
                <i class="ri-stack-line"></i>

                <div>
                  <span>Version</span>
                  <strong>{{ scormVersion }}</strong>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="viewer-hero-actions">
          <Link :href="route('courses.scorm.index')" class="btn btn-light">
            <i class="ri-arrow-left-line me-1"></i>
            Back
          </Link>

          <Link
            v-if="course.hashid"
            :href="route('courses.scorm.edit', course.hashid)"
            class="btn btn-outline-light"
          >
            <i class="ri-edit-2-line me-1"></i>
            Edit
          </Link>
        </div>
      </div>

      <div class="course-overview-strip">
        <div class="overview-card">
          <div class="overview-icon">
            <i class="ri-code-box-line"></i>
          </div>

          <div>
            <span>Course Format</span>
            <strong>SCORM</strong>
          </div>
        </div>

        <div class="overview-card">
          <div class="overview-icon">
            <i class="ri-stack-line"></i>
          </div>

          <div>
            <span>SCORM Version</span>
            <strong>{{ scormVersion }}</strong>
          </div>
        </div>

        <div class="overview-card">
          <div class="overview-icon">
            <i class="ri-bookmark-3-line"></i>
          </div>

          <div>
            <span>Category</span>
            <strong>{{ course.category?.name || '-' }}</strong>
          </div>
        </div>

        <div class="overview-card">
          <div class="overview-icon">
            <i class="ri-focus-3-line"></i>
          </div>

          <div>
            <span>Course Focus</span>
            <strong>{{ course.course_focus || 'Not specified' }}</strong>
          </div>
        </div>
      </div>

      <div class="slide-view-card">
        <div class="slide-topbar">
          <div class="slide-type">
            <i class="ri-code-box-line"></i>
            SCORM Package
          </div>

          <div class="slide-progress-text">
            {{ scormTitle }}
          </div>
        </div>

        <div class="chapter-context">
          <span>{{ scormVersion }}</span>
          <h5>{{ scormTitle }}</h5>
        </div>

        <div class="slide-content-box">
          <div v-if="course.scorm_launch_url" class="scorm-box">
            <iframe
              ref="scormFrame"
              :src="course.scorm_launch_url"
              class="scorm-frame"
              allowfullscreen
            ></iframe>
          </div>

          <div v-else class="empty-slide-content">
            <i class="ri-code-box-line"></i>
            <p>No SCORM package available.</p>
          </div>
        </div>
      </div>
    </div>
  </Layout>
</template>