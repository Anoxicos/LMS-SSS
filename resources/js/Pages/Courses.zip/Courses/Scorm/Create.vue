<script setup>
import { Head, Link, useForm } from '@inertiajs/vue3'
import Swal from 'sweetalert2'

import Layout from '@/Layouts/main.vue'
import PageHeader from '@/Components/page-header.vue'

import '../course-builder.css'
import ScormBasicInfo from './Partials/ScormBasicInfo.vue'

defineProps({
  categories: {
    type: Array,
    required: true,
  },
  tags: {
    type: Array,
    default: () => [],
  },
})

const form = useForm({
  title: '',
  description: '',
  category_id: '',
  type: '',
  training_type: '',
  skill_level: '',
  course_focus: '',
  language: 'English',
  price: 0,
  currency: 'MAD',
  is_published: false,
  tags: [],

  image: null,
  image_url: null,
  remove_image: false,

  scorm_file: null,
  scorm_zip_path: null,
  scorm_extract_path: null,
  scorm_entry_file: null,
  scorm_version: null,
  scorm_identifier: null,
  scorm_title: null,
  scorm_launch_url: null,
})

const submit = () => {
  form.post(route('courses.scorm.store'), {
    preserveScroll: true,
    forceFormData: true,
    onSuccess: () => {
      Swal.fire({
        icon: 'success',
        title: 'Created!',
        text: 'SCORM course has been created successfully.',
        timer: 1800,
        showConfirmButton: false,
      })
    },
    onError: () => {
      Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: 'Please check the SCORM course information.',
        timer: 2500,
        showConfirmButton: false,
      })
    },
  })
}
</script>

<template>
  <Layout>
    <Head title="Create SCORM Course" />
    <PageHeader title="Create SCORM Course" pageTitle="Courses" />

    <div class="course-builder-page">
      <BCard class="course-builder-card border-0 shadow-sm">
        <BCardHeader class="course-builder-header border-0">
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div class="course-title-box">
              <div class="course-main-icon">
                <i class="ri-code-box-line"></i>
              </div>

              <div>
                <h4 class="mb-1 fw-bold">Create SCORM Course</h4>
                <p class="text-muted mb-0">
                  Upload a SCORM package and configure course information.
                </p>
              </div>
            </div>

            <Link :href="route('courses.scorm.index')" class="btn btn-light back-btn">
              <i class="ri-arrow-left-line me-1"></i>
              Back to Courses
            </Link>
          </div>
        </BCardHeader>

        <BCardBody>
          <ScormBasicInfo
            :form="form"
            :categories="categories"
            :tags="tags"
            :is-editing="false"
          />

          <div class="builder-footer">
            <Link :href="route('courses.scorm.index')" class="btn btn-light footer-btn">
              <i class="ri-arrow-left-line me-1"></i>
              Cancel
            </Link>

            <BButton
              type="button"
              variant="warning"
              class="footer-btn"
              :disabled="form.processing"
              @click="submit"
            >
              <span
                v-if="form.processing"
                class="spinner-border spinner-border-sm me-1"
              ></span>
              <i v-else class="ri-save-line me-1"></i>
              Save SCORM Course
            </BButton>
          </div>
        </BCardBody>
      </BCard>
    </div>
  </Layout>
</template>