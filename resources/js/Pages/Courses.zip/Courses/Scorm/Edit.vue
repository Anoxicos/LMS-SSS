<script setup>
import { Head, Link, useForm } from '@inertiajs/vue3'
import Swal from 'sweetalert2'
import { watch } from 'vue'

import Layout from '@/Layouts/main.vue'
import PageHeader from '@/Components/page-header.vue'

import '../course-builder.css'
import ScormBasicInfo from './Partials/ScormBasicInfo.vue'

const props = defineProps({
  categories: {
    type: Array,
    required: true,
  },
  tags: {
    type: Array,
    default: () => [],
  },
  course: {
    type: Object,
    required: true,
  },
})

const toBoolean = (value) => {
  return value === true || value === 1 || value === '1' || value === 'true'
}

const form = useForm({
  title: '',
  description: '',
  category_id: '',
  type: '',
  training_type: '',
  skill_level: '',
  course_focus: '',
  language: 'English',
  price: 0,
  currency: 'MAD',
  is_published: false,
  tags: [],

  image: null,
  image_url: null,
  remove_image: false,

  scorm_file: null,
  scorm_zip_path: null,
  scorm_extract_path: null,
  scorm_entry_file: null,
  scorm_version: null,
  scorm_identifier: null,
  scorm_title: null,
  scorm_launch_url: null,
})

watch(
  () => props.course,
  (course) => {
    form.title = course.title || ''
    form.description = course.description || ''
    form.category_id = course.category_id || ''
    form.type = course.type || ''
    form.training_type = course.training_type || ''
    form.skill_level = course.skill_level || ''
    form.course_focus = course.course_focus || ''
    form.language = course.language || 'English'
    form.price = course.price || 0
    form.currency = course.currency || 'MAD'
    form.is_published = toBoolean(course.is_published)
    form.tags = course.tags?.map((tag) => tag.id) || []

    form.image = null
    form.image_url = course.image_url || null
    form.remove_image = false

    form.scorm_file = null
    form.scorm_zip_path = course.scorm_zip_path || null
    form.scorm_extract_path = course.scorm_extract_path || null
    form.scorm_entry_file = course.scorm_entry_file || null
    form.scorm_version = course.scorm_version || null
    form.scorm_identifier = course.scorm_identifier || null
    form.scorm_title = course.scorm_title || null
    form.scorm_launch_url = course.scorm_launch_url || null
  },
  {
    immediate: true,
    deep: true,
  }
)

const submit = () => {
  form.post(route('courses.scorm.update', props.course.hashid), {
    preserveScroll: true,
    forceFormData: true,
    onSuccess: () => {
      Swal.fire({
        icon: 'success',
        title: 'Updated!',
        text: 'SCORM course has been updated successfully.',
        timer: 1800,
        showConfirmButton: false,
      })
    },
    onError: () => {
      Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: 'Please check the SCORM course information.',
        timer: 2500,
        showConfirmButton: false,
      })
    },
  })
}
</script>

<template>
  <Layout>
    <Head title="Edit SCORM Course" />
    <PageHeader title="Edit SCORM Course" pageTitle="Courses" />

    <div class="course-builder-page">
      <BCard class="course-builder-card border-0 shadow-sm">
        <BCardHeader class="course-builder-header border-0">
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div class="course-title-box">
              <div class="course-main-icon">
                <i class="ri-code-box-line"></i>
              </div>

              <div>
                <h4 class="mb-1 fw-bold">Edit SCORM Course</h4>
                <p class="text-muted mb-0">
                  Update course information or replace the SCORM package.
                </p>
              </div>
            </div>

            <div class="d-flex flex-wrap gap-2">
              <Link
                :href="route('courses.scorm.show', course.hashid)"
                class="btn btn-soft-info back-btn"
              >
                <i class="ri-eye-line me-1"></i>
                View
              </Link>

              <Link :href="route('courses.scorm.index')" class="btn btn-light back-btn">
                <i class="ri-arrow-left-line me-1"></i>
                Back to Courses
              </Link>
            </div>
          </div>
        </BCardHeader>

        <BCardBody>
          <ScormBasicInfo
            :form="form"
            :categories="categories"
            :tags="tags"
            :is-editing="true"
          />

          <div class="builder-footer">
            <Link :href="route('courses.scorm.index')" class="btn btn-light footer-btn">
              <i class="ri-arrow-left-line me-1"></i>
              Cancel
            </Link>

            <BButton
              type="button"
              variant="warning"
              class="footer-btn"
              :disabled="form.processing"
              @click="submit"
            >
              <span
                v-if="form.processing"
                class="spinner-border spinner-border-sm me-1"
              ></span>
              <i v-else class="ri-save-line me-1"></i>
              Update SCORM Course
            </BButton>
          </div>
        </BCardBody>
      </BCard>
    </div>
  </Layout>
</template>