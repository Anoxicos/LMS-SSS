<script setup>
import { computed, ref, onMounted, onBeforeUnmount, watch, nextTick } from 'vue'
import { Head, Link } from '@inertiajs/vue3'

import Layout from '@/Layouts/main.vue'
import PageHeader from '@/Components/page-header.vue'

import './course-viewer.css'

const props = defineProps({
  course: {
    type: Object,
    required: true,
  },
})

const currentChapterIndex = ref(0)
const currentSlideIndex = ref(0)
const currentQuestionIndex = ref(0)
const voiceOverAudio = ref(null)

const chapters = computed(() => {
  return (props.course.chapters || []).filter((chapter) => {
    return Array.isArray(chapter.slides) && chapter.slides.length > 0
  })
})

const currentChapter = computed(() => {
  return chapters.value[currentChapterIndex.value] || null
})

const slides = computed(() => {
  return currentChapter.value?.slides || []
})

const currentSlide = computed(() => {
  return slides.value[currentSlideIndex.value] || null
})

const currentSlideQuestions = computed(() => {
  return currentSlide.value?.questions || []
})

const currentQuestion = computed(() => {
  return currentSlideQuestions.value[currentQuestionIndex.value] || null
})

const totalQuestions = computed(() => {
  return currentSlideQuestions.value.length
})

const hasQuizQuestions = computed(() => {
  return currentSlide.value?.lesson_type === 'quiz' && totalQuestions.value > 0
})

const isFirstQuestion = computed(() => {
  return currentQuestionIndex.value === 0
})

const isLastQuestion = computed(() => {
  return currentQuestionIndex.value === totalQuestions.value - 1
})

const totalSlides = computed(() => {
  return chapters.value.reduce((total, chapter) => {
    return total + (chapter.slides?.length || 0)
  }, 0)
})

const currentGlobalSlideNumber = computed(() => {
  if (!totalSlides.value || !currentSlide.value) {
    return 0
  }

  let count = 0

  for (let index = 0; index < currentChapterIndex.value; index++) {
    count += chapters.value[index]?.slides?.length || 0
  }

  const currentNumber = count + currentSlideIndex.value + 1

  return Math.min(currentNumber, totalSlides.value)
})

const progressPercent = computed(() => {
  if (!totalSlides.value || !currentSlide.value) {
    return 0
  }

  const progress = Math.round(
    (currentGlobalSlideNumber.value / totalSlides.value) * 100
  )

  return Math.min(100, Math.max(0, progress))
})

const courseImage = computed(() => {
  if (props.course.image_url) {
    return props.course.image_url
  }

  if (props.course.image) {
    return `/storage/${props.course.image}`
  }

  return null
})

const courseInitials = computed(() => {
  return String(props.course.title || 'CO')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word.charAt(0).toUpperCase())
    .join('')
})

const formattedCreatedAt = computed(() => {
  if (!props.course.created_at) return '-'

  return new Date(props.course.created_at).toLocaleDateString('en-GB', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  })
})

const formattedPrice = computed(() => {
  const price = Number(props.course.price || 0)

  if (props.course.type !== 'paid' || price === 0) {
    return 'Free'
  }

  return `${price.toFixed(2)} ${props.course.currency || ''}`
})

const courseStatusLabel = computed(() => {
  return props.course.is_published ? 'Published' : 'Draft'
})

const courseTypeLabel = computed(() => {
  return props.course.type || '-'
})

const voiceOverLabel = computed(() => {
  return props.course.support_voice_over ? 'Supported' : 'Not Supported'
})

const voiceOverAutoPlay = computed(() => {
  return Boolean(props.course.voice_over_auto_play)
})

const courseVoiceProviderLabel = computed(() => {
  return props.course.voice_over_provider || 'voicerss'
})

const courseVoiceLangLabel = computed(() => {
  const labels = {
    'en-us': 'English - US',
    'en-gb': 'English - UK',
    'fr-fr': 'French',
    'ar-sa': 'Arabic',
    'es-es': 'Spanish',
  }

  return labels[props.course.voice_over_lang] || props.course.voice_over_lang || 'English - US'
})

const courseVoiceNameLabel = computed(() => {
  return props.course.voice_over_voice || 'default'
})

const hasCurrentSlideVoiceOver = computed(() => {
  return Boolean(
    props.course.support_voice_over &&
      currentSlide.value &&
      currentSlide.value.voice_over_enabled &&
      currentSlide.value.voice_over_audio_url
  )
})

const currentSlideVoiceOverName = computed(() => {
  return currentSlide.value?.voice_over_audio_name || 'Generated voice over'
})

const selectChapter = (chapterIndex) => {
  currentChapterIndex.value = chapterIndex
  currentSlideIndex.value = 0
  currentQuestionIndex.value = 0
}

const selectSlide = (slideIndex) => {
  currentSlideIndex.value = slideIndex
  currentQuestionIndex.value = 0
}

const goNext = () => {
  if (!currentChapter.value) return

  currentQuestionIndex.value = 0

  if (currentSlideIndex.value < slides.value.length - 1) {
    currentSlideIndex.value++
    return
  }

  if (currentChapterIndex.value < chapters.value.length - 1) {
    currentChapterIndex.value++
    currentSlideIndex.value = 0
  }
}

const goPrevious = () => {
  currentQuestionIndex.value = 0

  if (currentSlideIndex.value > 0) {
    currentSlideIndex.value--
    return
  }

  if (currentChapterIndex.value > 0) {
    currentChapterIndex.value--

    const previousChapterSlides =
      chapters.value[currentChapterIndex.value]?.slides || []

    currentSlideIndex.value = previousChapterSlides.length
      ? previousChapterSlides.length - 1
      : 0
  }
}

const goNextQuestion = () => {
  if (currentQuestionIndex.value < totalQuestions.value - 1) {
    currentQuestionIndex.value++
  }
}

const goPreviousQuestion = () => {
  if (currentQuestionIndex.value > 0) {
    currentQuestionIndex.value--
  }
}

const selectQuestion = (index) => {
  currentQuestionIndex.value = index
}

const isFirstSlide = computed(() => {
  return currentChapterIndex.value === 0 && currentSlideIndex.value === 0
})

const isLastSlide = computed(() => {
  return (
    currentChapterIndex.value === chapters.value.length - 1 &&
    currentSlideIndex.value === slides.value.length - 1
  )
})

const getSlideIcon = (type) => {
  if (type === 'video') return 'ri-video-line'
  if (type === 'file') return 'ri-file-3-line'
  if (type === 'link') return 'ri-links-line'
  if (type === 'quiz') return 'ri-question-answer-line'

  return 'ri-text-snippet'
}

const normalizeQuestionType = (question) => {
  return question?.question_type === 'true_false'
    ? 'true_false'
    : 'qcm'
}

const getQuestionTypeLabel = (question) => {
  return normalizeQuestionType(question) === 'true_false'
    ? 'True / False'
    : 'QCM'
}

const getQuestionTypeIcon = (question) => {
  return normalizeQuestionType(question) === 'true_false'
    ? 'ri-toggle-line'
    : 'ri-list-check-3'
}

const getQuestionTypeBadgeClass = (question) => {
  return normalizeQuestionType(question) === 'true_false'
    ? 'true-false'
    : 'qcm'
}

const getCorrectAnswerLabel = (answer) => {
  const normalizedAnswer = String(answer || '').toLowerCase()

  if (normalizedAnswer === 'a') return 'Option A'
  if (normalizedAnswer === 'b') return 'Option B'
  if (normalizedAnswer === 'c') return 'Option C'
  if (normalizedAnswer === 'true') return 'True'
  if (normalizedAnswer === 'false') return 'False'

  return '-'
}

const getCorrectAnswerText = (question) => {
  if (!question) return '-'

  const questionType = normalizeQuestionType(question)
  const correctAnswer = String(question.correct_answer || '').toLowerCase()

  if (questionType === 'true_false') {
    if (correctAnswer === 'true') return 'True'
    if (correctAnswer === 'false') return 'False'

    return '-'
  }

  if (correctAnswer === 'a') return question.option_a || '-'
  if (correctAnswer === 'b') return question.option_b || '-'
  if (correctAnswer === 'c') return question.option_c || '-'

  return '-'
}

const getQuestionOptions = (question) => {
  if (!question) return []

  if (normalizeQuestionType(question) === 'true_false') {
    return [
      {
        key: 'true',
        label: 'T',
        value: 'True',
      },
      {
        key: 'false',
        label: 'F',
        value: 'False',
      },
    ]
  }

  return [
    {
      key: 'a',
      label: 'A',
      value: question.option_a,
    },
    {
      key: 'b',
      label: 'B',
      value: question.option_b,
    },
    {
      key: 'c',
      label: 'C',
      value: question.option_c,
    },
  ].filter((option) => Boolean(option.value))
}

const isImageFile = (slide) => {
  if (!slide) return false

  const fileType = String(slide.file_type || '').toLowerCase()
  const fileName = String(slide.file_name || '').toLowerCase()

  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp']

  return imageExtensions.some((ext) => {
    return fileType === ext || fileName.endsWith(`.${ext}`)
  })
}

const getVideoEmbedUrl = (url) => {
  if (!url) return ''

  try {
    const parsedUrl = new URL(url)

    if (parsedUrl.hostname.includes('youtube.com')) {
      const videoId = parsedUrl.searchParams.get('v')

      if (videoId) {
        return `https://www.youtube.com/embed/${videoId}`
      }
    }

    if (parsedUrl.hostname.includes('youtu.be')) {
      const videoId = parsedUrl.pathname.replace('/', '')

      if (videoId) {
        return `https://www.youtube.com/embed/${videoId}`
      }
    }

    return url
  } catch (error) {
    return url
  }
}

const resetVoiceOverAudio = () => {
  if (!voiceOverAudio.value) return

  voiceOverAudio.value.pause()
  voiceOverAudio.value.currentTime = 0
}

const playVoiceOverIfNeeded = async () => {
  await nextTick()

  if (!voiceOverAudio.value) return
  if (!hasCurrentSlideVoiceOver.value) return
  if (!voiceOverAutoPlay.value) return

  try {
    voiceOverAudio.value.currentTime = 0
    await voiceOverAudio.value.play()
  } catch (error) {
    // Le navigateur peut bloquer autoplay avant une interaction utilisateur.
  }
}

watch(
  chapters,
  (availableChapters) => {
    if (!availableChapters.length) {
      currentChapterIndex.value = 0
      currentSlideIndex.value = 0
      currentQuestionIndex.value = 0

      return
    }

    if (currentChapterIndex.value >= availableChapters.length) {
      currentChapterIndex.value = 0
      currentSlideIndex.value = 0
      currentQuestionIndex.value = 0

      return
    }

    const availableSlides =
      availableChapters[currentChapterIndex.value]?.slides || []

    if (currentSlideIndex.value >= availableSlides.length) {
      currentSlideIndex.value = 0
      currentQuestionIndex.value = 0
    }
  },
  {
    immediate: true,
    deep: true,
  }
)


watch(
  () => currentSlide.value?.id,
  () => {
    currentQuestionIndex.value = 0
    resetVoiceOverAudio()
    playVoiceOverIfNeeded()
  }
)

watch(
  () => currentSlide.value?.voice_over_audio_url,
  () => {
    resetVoiceOverAudio()
    playVoiceOverIfNeeded()
  }
)

const blockActions = (event) => {
  event.preventDefault()
}

const blockKeyboardShortcuts = (event) => {
  const key = event.key.toLowerCase()

  if (
    event.ctrlKey &&
    ['c', 'v', 'x', 's', 'u', 'p', 'a'].includes(key)
  ) {
    event.preventDefault()
  }

  if (event.key === 'F12') {
    event.preventDefault()
  }

  if (
    event.ctrlKey &&
    event.shiftKey &&
    ['i', 'j', 'c'].includes(key)
  ) {
    event.preventDefault()
  }

  if (event.key === 'PrintScreen') {
    event.preventDefault()

    if (navigator.clipboard) {
      navigator.clipboard.writeText('')
    }
  }
}

onMounted(() => {
  document.addEventListener('contextmenu', blockActions)
  document.addEventListener('copy', blockActions)
  document.addEventListener('cut', blockActions)
  document.addEventListener('paste', blockActions)
  document.addEventListener('dragstart', blockActions)
  document.addEventListener('keydown', blockKeyboardShortcuts)

  playVoiceOverIfNeeded()
})

onBeforeUnmount(() => {
  resetVoiceOverAudio()

  document.removeEventListener('contextmenu', blockActions)
  document.removeEventListener('copy', blockActions)
  document.removeEventListener('cut', blockActions)
  document.removeEventListener('paste', blockActions)
  document.removeEventListener('dragstart', blockActions)
  document.removeEventListener('keydown', blockKeyboardShortcuts)
})
</script>

<template>
  <Layout>
    <Head :title="course.title" />
    <PageHeader title="Course Details" pageTitle="Courses" />

    <div class="course-viewer-page protected-content">
      <div class="viewer-hero pro-hero">
        <div class="viewer-hero-main">
          <div class="viewer-course-cover">
            <img
              v-if="courseImage"
              :src="courseImage"
              :alt="course.title"
              draggable="false"
              @contextmenu.prevent
            />

            <div v-else class="viewer-course-cover-fallback">
              {{ courseInitials }}
            </div>
          </div>

          <div class="viewer-hero-content">
            <div class="viewer-badge-row">
              <span class="viewer-badge">
                <i class="ri-price-tag-3-line"></i>
                {{ course.category?.name || 'Course' }}
              </span>

              <span
                class="viewer-badge"
                :class="course.is_published ? 'badge-success' : 'badge-warning'"
              >
                <i :class="course.is_published ? 'ri-checkbox-circle-line' : 'ri-draft-line'"></i>
                {{ courseStatusLabel }}
              </span>

              <span
                class="viewer-badge"
                :class="course.support_voice_over ? 'badge-info' : 'badge-muted'"
              >
                <i class="ri-mic-line"></i>
                {{ voiceOverLabel }}
              </span>

              <span
                v-if="course.support_voice_over"
                class="viewer-badge"
                :class="voiceOverAutoPlay ? 'badge-info' : 'badge-muted'"
              >
                <i :class="voiceOverAutoPlay ? 'ri-play-circle-line' : 'ri-pause-circle-line'"></i>
                {{ voiceOverAutoPlay ? 'Auto Play' : 'Manual Play' }}
              </span>

              <span
                v-if="course.support_voice_over"
                class="viewer-badge badge-info"
              >
                <i class="ri-user-voice-line"></i>
                {{ courseVoiceLangLabel }} / {{ courseVoiceNameLabel }}
              </span>

              <span class="viewer-badge badge-date">
                <i class="ri-calendar-line"></i>
                {{ formattedCreatedAt }}
              </span>
            </div>

            <h2>{{ course.title }}</h2>

            <p>
              {{ course.description || 'No description available for this course.' }}
            </p>

            <div class="course-info-grid">
              <div class="course-info-item">
                <i class="ri-graduation-cap-line"></i>

                <div>
                  <span>Type</span>
                  <strong>{{ courseTypeLabel }}</strong>
                </div>
              </div>

              <div class="course-info-item">
                <i class="ri-computer-line"></i>

                <div>
                  <span>Training</span>
                  <strong>{{ course.training_type || '-' }}</strong>
                </div>
              </div>

              <div class="course-info-item">
                <i class="ri-bar-chart-line"></i>

                <div>
                  <span>Level</span>
                  <strong>{{ course.skill_level || '-' }}</strong>
                </div>
              </div>

              <div class="course-info-item">
                <i class="ri-translate-2"></i>

                <div>
                  <span>Language</span>
                  <strong>{{ course.language || '-' }}</strong>
                </div>
              </div>

              <div class="course-info-item">
                <i class="ri-money-dollar-circle-line"></i>

                <div>
                  <span>Price</span>
                  <strong>{{ formattedPrice }}</strong>
                </div>
              </div>

              <div class="course-info-item stat-info-item">
                <i class="ri-list-check-2"></i>

                <div>
                  <span>Chapters</span>
                  <strong>{{ chapters.length }}</strong>
                </div>
              </div>

              <div class="course-info-item stat-info-item">
                <i class="ri-slideshow-line"></i>

                <div>
                  <span>Slides</span>
                  <strong>{{ totalSlides }}</strong>
                </div>
              </div>

              <div class="course-info-item stat-info-item">
                <i class="ri-line-chart-line"></i>

                <div>
                  <span>Progress</span>
                  <strong>{{ progressPercent }}%</strong>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="viewer-hero-actions">
          <Link :href="route('courses.index')" class="btn btn-light">
            <i class="ri-arrow-left-line me-1"></i>
            Back
          </Link>

          <Link
            v-if="course.hashid"
            :href="route('courses.edit', course.hashid)"
            class="btn btn-outline-light"
          >
            <i class="ri-edit-2-line me-1"></i>
            Edit
          </Link>
        </div>
      </div>

      <div class="course-overview-strip">
        <div class="overview-card">
          <div class="overview-icon">
            <i class="ri-focus-3-line"></i>
          </div>

          <div>
            <span>Course Focus</span>
            <strong>{{ course.course_focus || 'Not specified' }}</strong>
          </div>
        </div>

        <div class="overview-card">
          <div class="overview-icon">
            <i class="ri-mic-line"></i>
          </div>

          <div>
            <span>Voice Over</span>
            <strong>{{ voiceOverLabel }}</strong>
          </div>
        </div>

        <div class="overview-card">
          <div class="overview-icon">
            <i class="ri-play-circle-line"></i>
          </div>

          <div>
            <span>Audio Mode</span>
            <strong>
              {{
                course.support_voice_over
                  ? voiceOverAutoPlay
                    ? 'Auto Play'
                    : 'Manual Play'
                  : 'Disabled'
              }}
            </strong>
          </div>
        </div>

        <div class="overview-card">
          <div class="overview-icon">
            <i class="ri-user-voice-line"></i>
          </div>

          <div>
            <span>Voice</span>
            <strong>
              {{
                course.support_voice_over
                  ? `${courseVoiceLangLabel} / ${courseVoiceNameLabel}`
                  : 'Disabled'
              }}
            </strong>
          </div>
        </div>
      </div>

      <BRow class="g-4">
        <BCol lg="4" xl="3">
          <div class="chapters-sidebar">
            <div class="sidebar-title">
              <div>
                <h6>Course Content</h6>
                <span>{{ totalSlides }} total slides</span>
              </div>
            </div>

            <div class="viewer-progress">
              <div class="viewer-progress-info">
                <span>Progress</span>
                <strong>{{ progressPercent }}%</strong>
              </div>

              <div class="viewer-progress-bar">
                <div :style="{ width: `${progressPercent}%` }"></div>
              </div>
            </div>

            <div
              v-for="(chapter, chapterIndex) in chapters"
              :key="chapter.id"
              class="chapter-block"
            >
              <div
                class="chapter-item"
                :class="{ active: currentChapterIndex === chapterIndex }"
                @click="selectChapter(chapterIndex)"
              >
                <div class="chapter-number">
                  {{ chapterIndex + 1 }}
                </div>

                <div class="min-width-0 flex-grow-1">
                  <h6>{{ chapter.title }}</h6>

                  <p>
                    {{ chapter.slides?.length || 0 }}
                    slide{{ Number(chapter.slides?.length || 0) > 1 ? 's' : '' }}
                  </p>
                </div>
              </div>

              <div
                v-if="currentChapterIndex === chapterIndex"
                class="chapter-slides-mini"
              >
                <button
                  v-for="(slide, slideIndex) in chapter.slides"
                  :key="slide.id"
                  type="button"
                  class="mini-slide-item"
                  :class="{ active: currentSlideIndex === slideIndex }"
                  @click="selectSlide(slideIndex)"
                >
                  <i :class="getSlideIcon(slide.lesson_type)"></i>

                  <span>{{ slide.title }}</span>

                  <i
                    v-if="slide.voice_over_enabled && slide.voice_over_audio_url"
                    class="ri-volume-up-line mini-voice-icon"
                    title="Voice over available"
                  ></i>

                  <i
                    v-if="slide.lesson_type === 'quiz'"
                    class="ri-question-answer-line mini-voice-icon"
                    title="Quiz slide"
                  ></i>
                </button>
              </div>
            </div>
          </div>
        </BCol>

        <BCol lg="8" xl="9">
          <div v-if="currentSlide" class="slide-view-card">
            <div class="slide-topbar">
              <div class="slide-type">
                <i :class="getSlideIcon(currentSlide.lesson_type)"></i>
                {{ currentSlide.lesson_type || 'text' }}
              </div>

              <div class="slide-progress-text">
                Slide {{ currentGlobalSlideNumber }} / {{ totalSlides }}
              </div>
            </div>

            <div class="chapter-context">
              <span>{{ currentChapter?.title || 'Chapter' }}</span>
              <h5>{{ currentSlide.title }}</h5>
            </div>

            <div
              v-if="hasCurrentSlideVoiceOver"
              class="slide-voice-over-card"
            >
              <div class="voice-over-main">
                <div class="voice-over-icon">
                  <i class="ri-volume-up-line"></i>
                </div>

                <div class="flex-grow-1 min-width-0">
                  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                    <div class="min-width-0">
                      <h6 class="mb-1 text-truncate">
                        {{ currentSlideVoiceOverName }}
                      </h6>

                      <div class="voice-over-meta">
                        <span>
                          <i class="ri-translate-2 me-1"></i>
                          {{ courseVoiceLangLabel }}
                        </span>

                        <span>
                          <i class="ri-user-voice-line me-1"></i>
                          {{ courseVoiceNameLabel }}
                        </span>

                        <span>
                          <i class="ri-sparkling-line me-1"></i>
                          {{ courseVoiceProviderLabel }}
                        </span>
                      </div>
                    </div>

                    <span
                      class="voice-mode-badge"
                      :class="voiceOverAutoPlay ? 'auto' : 'manual'"
                    >
                      <i :class="voiceOverAutoPlay ? 'ri-play-circle-line' : 'ri-pause-circle-line'"></i>
                      {{ voiceOverAutoPlay ? 'Auto Play' : 'Manual Play' }}
                    </span>
                  </div>

                  <audio
                    ref="voiceOverAudio"
                    class="voice-over-audio"
                    controls
                    controlsList="nodownload"
                    :src="currentSlide.voice_over_audio_url"
                    @contextmenu.prevent
                  ></audio>
                </div>
              </div>
            </div>

            <div
              v-else-if="course.support_voice_over"
              class="slide-voice-over-empty"
            >
              <i class="ri-mic-off-line"></i>
              <span>No voice over for this slide.</span>
            </div>

            <div class="slide-content-box">
              <div
                v-if="currentSlide.lesson_type === 'text'"
                class="slide-rich-content protected-text"
                v-html="currentSlide.content || 'No content available.'"
              ></div>

              <div v-else-if="currentSlide.lesson_type === 'video'" class="video-box">
                <iframe
                  v-if="currentSlide.video_url"
                  :src="getVideoEmbedUrl(currentSlide.video_url)"
                  frameborder="0"
                  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowfullscreen
                  sandbox="allow-same-origin allow-scripts allow-presentation"
                ></iframe>

                <div v-else class="empty-slide-content">
                  <i class="ri-video-off-line"></i>
                  <p>No video URL available.</p>
                </div>

                <div
                  v-if="currentSlide.content"
                  class="slide-rich-content mt-3 protected-text"
                  v-html="currentSlide.content"
                ></div>
              </div>

              <div v-else-if="currentSlide.lesson_type === 'file'">
                <div
                  v-if="isImageFile(currentSlide)"
                  class="image-preview-box protected-media"
                >
                  <img
                    :src="currentSlide.file_url"
                    :alt="currentSlide.file_name || currentSlide.title"
                    draggable="false"
                    @contextmenu.prevent
                  />
                </div>

                <div v-else class="file-box protected-file-box">
                  <div class="file-icon">
                    <i class="ri-file-lock-line"></i>
                  </div>

                  <div class="flex-grow-1">
                    <h6>{{ currentSlide.file_name || 'Protected file' }}</h6>

                    <p class="text-muted mb-0">
                      Download is disabled for this course file.
                    </p>
                  </div>
                </div>
              </div>

              <div v-else-if="currentSlide.lesson_type === 'link'" class="file-box">
                <div class="file-icon">
                  <i class="ri-links-line"></i>
                </div>

                <div>
                  <h6>External Resource</h6>

                  <a
                    v-if="currentSlide.external_url"
                    :href="currentSlide.external_url"
                    target="_blank"
                    class="btn btn-primary btn-sm"
                  >
                    <i class="ri-external-link-line me-1"></i>
                    Open Link
                  </a>

                  <p v-else class="text-muted mb-0">
                    No external URL available.
                  </p>
                </div>
              </div>

              <div v-else-if="currentSlide.lesson_type === 'quiz'" class="admin-quiz-box">
                <div class="admin-quiz-header">
                  <div>
                    <span class="admin-quiz-kicker">
                      <i class="ri-question-answer-line"></i>
                      Quiz Structure
                    </span>

                    <h5>Comprehension Questions</h5>
                  </div>

                  <div class="admin-quiz-count">
                    <span>Questions</span>
                    <strong>{{ totalQuestions }}</strong>
                  </div>
                </div>

                <div v-if="!hasQuizQuestions" class="empty-slide-content">
                  <i class="ri-question-line"></i>
                  <p>No questions available for this quiz slide.</p>
                </div>

                <div v-else>
                  <div class="admin-question-progress">
                    <span>
                      Question {{ currentQuestionIndex + 1 }} of {{ totalQuestions }}
                    </span>

                    <div class="admin-question-dots">
                      <button
                        v-for="(question, index) in currentSlideQuestions"
                        :key="question.id"
                        type="button"
                        :class="{ active: currentQuestionIndex === index }"
                        @click="selectQuestion(index)"
                      >
                        {{ index + 1 }}
                      </button>
                    </div>
                  </div>

                  <div class="admin-question-card">
                    <div class="admin-question-title">
                      <div class="admin-question-number">
                        {{ currentQuestionIndex + 1 }}
                      </div>

                      <div class="flex-grow-1 min-width-0">
                        <div class="admin-question-heading-meta">
                          <span>Question</span>

                          <span
                            class="admin-question-type-badge"
                            :class="getQuestionTypeBadgeClass(currentQuestion)"
                          >
                            <i :class="getQuestionTypeIcon(currentQuestion)"></i>
                            {{ getQuestionTypeLabel(currentQuestion) }}
                          </span>
                        </div>

                        <h6>{{ currentQuestion.question }}</h6>
                      </div>
                    </div>

                    <div
                      class="admin-options-list"
                      :class="{
                        'true-false-options':
                          normalizeQuestionType(currentQuestion) === 'true_false',
                      }"
                    >
                      <div
                        v-for="option in getQuestionOptions(currentQuestion)"
                        :key="option.key"
                        class="admin-option-row"
                        :class="{
                          correct:
                            String(currentQuestion.correct_answer || '').toLowerCase() ===
                            option.key,
                        }"
                      >
                        <div class="admin-option-letter">
                          {{ option.label }}
                        </div>

                        <div class="admin-option-text">
                          {{ option.value }}
                        </div>

                        <div
                          v-if="
                            String(currentQuestion.correct_answer || '').toLowerCase() ===
                            option.key
                          "
                          class="admin-correct-badge"
                        >
                          <i class="ri-checkbox-circle-line"></i>
                          Correct
                        </div>
                      </div>
                    </div>

                    <div
                      v-if="currentQuestion.explanation"
                      class="admin-explanation-box"
                    >
                      <span>
                        <i class="ri-lightbulb-line"></i>
                        Explanation
                      </span>

                      <p>{{ currentQuestion.explanation }}</p>
                    </div>
                  </div>

                  <div class="admin-question-navigation">
                    <BButton
                      variant="light"
                      class="nav-slide-btn"
                      :disabled="isFirstQuestion"
                      @click="goPreviousQuestion"
                    >
                      <i class="ri-arrow-left-line me-1"></i>
                      Previous Question
                    </BButton>

                    <BButton
                      variant="primary"
                      class="nav-slide-btn"
                      :disabled="isLastQuestion"
                      @click="goNextQuestion"
                    >
                      Next Question
                      <i class="ri-arrow-right-line ms-1"></i>
                    </BButton>
                  </div>
                </div>
              </div>

              <div v-else class="slide-rich-content protected-text">
                {{ currentSlide.content || 'No content available.' }}
              </div>
            </div>

            <div class="slide-navigation">
              <BButton
                variant="light"
                class="nav-slide-btn"
                :disabled="isFirstSlide"
                @click="goPrevious"
              >
                <i class="ri-arrow-left-line me-1"></i>
                Previous Slide
              </BButton>

              <div class="slide-dots">
                <button
                  v-for="(slide, index) in slides"
                  :key="slide.id"
                  type="button"
                  :class="{ active: currentSlideIndex === index }"
                  @click="selectSlide(index)"
                ></button>
              </div>

              <BButton
                variant="primary"
                class="nav-slide-btn"
                :disabled="isLastSlide"
                @click="goNext"
              >
                Next Slide
                <i class="ri-arrow-right-line ms-1"></i>
              </BButton>
            </div>
          </div>

          <div v-else class="empty-viewer">
            <i class="ri-slideshow-line"></i>
            <h5>No slides available</h5>
            <p>This course does not have slides yet.</p>
          </div>
        </BCol>
      </BRow>
    </div>
  </Layout>
</template>


<style scoped>
.admin-question-heading-meta {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 6px;
}

.admin-question-type-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 10px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
  line-height: 1;
  letter-spacing: 0.02em;
}

.admin-question-type-badge.qcm {
  color: #405189;
  background: rgba(64, 81, 137, 0.12);
  border: 1px solid rgba(64, 81, 137, 0.18);
}

.admin-question-type-badge.true-false {
  color: #0ab39c;
  background: rgba(10, 179, 156, 0.12);
  border: 1px solid rgba(10, 179, 156, 0.2);
}

.true-false-options {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.true-false-options .admin-option-row {
  min-height: 72px;
}

@media (max-width: 575.98px) {
  .admin-question-heading-meta {
    align-items: flex-start;
    flex-direction: column;
  }

  .true-false-options {
    grid-template-columns: 1fr;
  }
}
</style>
