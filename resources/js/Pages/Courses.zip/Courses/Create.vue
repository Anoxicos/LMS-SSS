<script setup>
import { Head, Link, useForm } from '@inertiajs/vue3'
import Swal from 'sweetalert2'

import Layout from '@/Layouts/main.vue'
import PageHeader from '@/Components/page-header.vue'

import './course-builder.css'
import CourseBasicInfo from './Partials/CourseBasicInfo.vue'

defineProps({
  categories: {
    type: Array,
    required: true,
  },
  tags: {
    type: Array,
    default: () => [],
  },
})

const form = useForm({
  title: '',
  description: '',
  category_id: '',
  type: '',
  training_type: '',
  skill_level: '',
  course_focus: '',
  language: 'English',
  price: 0,
  currency: 'MAD',
  is_published: false,
  tags: [],

  image: null,
  image_url: null,
  remove_image: false,

  support_voice_over: false,
  voice_over_auto_play: false,
  voice_over_provider: 'voicerss',
  voice_over_lang: 'en-us',
  voice_over_voice: 'default',
})

const submit = () => {
  form.post(route('courses.store'), {
    preserveScroll: true,
    forceFormData: true,
    onSuccess: () => {
      Swal.fire({
        icon: 'success',
        title: 'Created!',
        text: 'Course has been created successfully.',
        timer: 1800,
        showConfirmButton: false,
      })
    },
    onError: () => {
      Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: 'Please check the course information.',
        timer: 2500,
        showConfirmButton: false,
      })
    },
  })
}
</script>

<template>
  <Layout>
    <Head title="Create Course" />
    <PageHeader title="Create Course" pageTitle="Courses" />

    <div class="course-builder-page">
      <BCard class="course-builder-card border-0 shadow-sm">
        <BCardHeader class="course-builder-header border-0">
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div class="course-title-box">
              <div class="course-main-icon">
                <i class="ri-book-open-line"></i>
              </div>

              <div>
                <h4 class="mb-1 fw-bold">Create Course</h4>
                <p class="text-muted mb-0">
                  Start by saving the main course information.
                </p>
              </div>
            </div>

            <Link :href="route('courses.index')" class="btn btn-light back-btn">
              <i class="ri-arrow-left-line me-1"></i>
              Back to Courses
            </Link>
          </div>
        </BCardHeader>

        <BCardBody>
          <CourseBasicInfo
            :form="form"
            :categories="categories"
            :tags="tags"
          />

          <div class="builder-footer">
            <Link :href="route('courses.index')" class="btn btn-light footer-btn">
              <i class="ri-arrow-left-line me-1"></i>
              Cancel
            </Link>

            <BButton
              type="button"
              variant="success"
              class="footer-btn"
              :disabled="form.processing"
              @click="submit"
            >
              <span
                v-if="form.processing"
                class="spinner-border spinner-border-sm me-1"
              ></span>
              <i v-else class="ri-save-line me-1"></i>
              Save & Continue
            </BButton>
          </div>
        </BCardBody>
      </BCard>
    </div>
  </Layout>
</template>