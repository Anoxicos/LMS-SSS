<script setup>
import { computed, ref, watch } from 'vue'
import { Head, Link, useForm } from '@inertiajs/vue3'
import Swal from 'sweetalert2'

import Layout from '@/Layouts/main.vue'
import PageHeader from '@/Components/page-header.vue'

import './course-builder.css'

import CourseBasicInfo from './Partials/CourseBasicInfo.vue'
import CourseChapters from './Partials/CourseChapters.vue'
import CourseSlides from './Partials/CourseSlides.vue'
import CoursePlan from './Partials/CoursePlan.vue'
import CourseReview from './Partials/CourseReview.vue'

const props = defineProps({
  categories: {
    type: Array,
    required: true,
  },
  tags: {
    type: Array,
    default: () => [],
  },
  course: {
    type: Object,
    required: true,
  },
  step: {
    type: Number,
    default: 1,
  },
})

const toBoolean = (value) => {
  return value === true || value === 1 || value === '1' || value === 'true'
}

const currentStep = ref(Number(props.step || 1))

watch(
  () => props.step,
  (newStep) => {
    currentStep.value = Number(newStep || 1)
  }
)

const steps = [
  { id: 1, title: 'Course Information', icon: 'ri-book-open-line' },
  { id: 2, title: 'Chapters', icon: 'ri-list-check-2' },
  { id: 3, title: 'Slides', icon: 'ri-slideshow-line' },
  { id: 4, title: 'Plan', icon: 'ri-stack-line' },
  { id: 5, title: 'Review', icon: 'ri-checkbox-circle-line' },
]

const form = useForm({
  title: '',
  description: '',
  category_id: '',
  type: '',
  training_type: '',
  skill_level: '',
  course_focus: '',
  language: 'English',
  price: 0,
  currency: 'MAD',
  is_published: false,
  tags: [],

  chapters: [],

  plan: {
    name: '',
    is_active: true,
    details: [],
  },

  image: null,
  image_url: null,
  remove_image: false,

  support_voice_over: false,
  voice_over_auto_play: false,
  voice_over_provider: 'voicerss',
  voice_over_lang: 'en-us',
  voice_over_voice: 'default',
})

watch(
  () => props.course,
  (course) => {
    form.title = course.title || ''
    form.description = course.description || ''
    form.category_id = course.category_id || ''
    form.type = course.type || ''
    form.training_type = course.training_type || ''
    form.skill_level = course.skill_level || ''
    form.course_focus = course.course_focus || ''
    form.language = course.language || 'English'
    form.price = course.price || 0
    form.currency = course.currency || 'MAD'
    form.is_published = toBoolean(course.is_published)
    form.tags = course.tags?.map((tag) => tag.id) || []

    form.chapters = course.chapters || []

    form.plan = course.plan || {
      name: '',
      is_active: true,
      details: [],
    }

    form.image = null
    form.image_url = course.image_url || null
    form.remove_image = false

    form.support_voice_over = toBoolean(course.support_voice_over)
    form.voice_over_auto_play = toBoolean(course.voice_over_auto_play)
    form.voice_over_provider = course.voice_over_provider || 'voicerss'
    form.voice_over_lang = course.voice_over_lang || 'en-us'
    form.voice_over_voice = course.voice_over_voice || 'default'
  },
  {
    immediate: true,
    deep: true,
  }
)

const isFirstStep = computed(() => currentStep.value === 1)
const isLastStep = computed(() => currentStep.value === steps.length)

const selectedCategory = computed(() => {
  return props.categories.find((category) => {
    return Number(category.id) === Number(form.category_id)
  })
})

const totalSlides = computed(() => {
  return form.chapters.reduce((total, chapter) => {
    return total + (chapter.slides?.length || 0)
  }, 0)
})

const showSuccess = (message) => {
  Swal.fire({
    icon: 'success',
    title: 'Saved!',
    text: message,
    timer: 1800,
    showConfirmButton: false,
  })
}

const showError = (message = 'Please check the form and try again.') => {
  Swal.fire({
    icon: 'error',
    title: 'Error!',
    text: message,
    timer: 2500,
    showConfirmButton: false,
  })
}

const validateBasicInfo = () => {
  if (!form.title || !form.category_id || !form.type || !form.training_type) {
    Swal.fire({
      icon: 'warning',
      title: 'Required fields',
      text: 'Please fill in the required course information.',
      timer: 2500,
      showConfirmButton: false,
    })

    return false
  }

  return true
}

const goToStep = (stepId) => {
  currentStep.value = stepId
}

const previousStep = () => {
  if (currentStep.value > 1) {
    currentStep.value--
  }
}

const nextStep = () => {
  if (currentStep.value < steps.length) {
    currentStep.value++
  }
}

const saveBasicInfo = (goNext = false) => {
  if (!validateBasicInfo()) return

  form.post(route('courses.update', props.course.id), {
    preserveScroll: true,
    preserveState: false,
    forceFormData: true,
    onSuccess: () => {
      showSuccess('Course information has been saved successfully.')

      if (goNext && currentStep.value < steps.length) {
        currentStep.value++
      }
    },
    onError: () => {
      showError('Please check the course information.')
    },
  })
}

const savePlan = (goNext = false) => {
  form
    .transform(() => ({
      name: form.plan.name,
      is_active: form.plan.is_active,
      next_step: goNext ? 5 : 4,
    }))
    .post(route('courses.plan.update', props.course.id), {
      preserveScroll: true,
      preserveState: false,
      onSuccess: () => {
        showSuccess('Plan has been saved successfully.')
      },
      onError: () => {
        showError('Please check plan and try again.')
      },
      onFinish: () => {
        form.transform((data) => data)
      },
    })
}

const saveCurrentStep = (goNext = false) => {
  if (currentStep.value === 1) {
    saveBasicInfo(goNext)
    return
  }

  if (currentStep.value === 2) {
    if (goNext && currentStep.value < steps.length) {
      currentStep.value++
    }
    return
  }

  if (currentStep.value === 3) {
    if (goNext && currentStep.value < steps.length) {
      currentStep.value++
    }
    return
  }

  if (currentStep.value === 4) {
    savePlan(goNext)
    return
  }

  if (currentStep.value === 5) {
    showSuccess('Course review completed.')
  }
}
</script>

<template>
  <Layout>
    <Head title="Edit Course" />
    <PageHeader title="Edit Course" pageTitle="Courses" />

    <div class="course-builder-page">
      <BCard class="course-builder-card border-0 shadow-sm">
        <BCardHeader class="course-builder-header border-0">
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div class="course-title-box">
              <div class="course-main-icon">
                <i class="ri-edit-2-line"></i>
              </div>

              <div>
                <h4 class="mb-1 fw-bold">Edit Course</h4>
                <p class="text-muted mb-0">
                  Complete or update course chapters, slides and plan.
                </p>
              </div>
            </div>

            <Link :href="route('courses.index')" class="btn btn-light back-btn">
              <i class="ri-arrow-left-line me-1"></i>
              Back to Courses
            </Link>
          </div>
        </BCardHeader>

        <BCardBody>
          <div class="builder-steps mb-4">
            <button
              v-for="stepItem in steps"
              :key="stepItem.id"
              type="button"
              class="builder-step"
              :class="{
                active: currentStep === stepItem.id,
                completed: currentStep > stepItem.id,
              }"
              @click="goToStep(stepItem.id)"
            >
              <span class="step-icon">
                <i
                  class="step-remix-icon"
                  :class="currentStep > stepItem.id ? 'ri-check-line' : stepItem.icon"
                ></i>
              </span>

              <span class="step-title">
                {{ stepItem.title }}
              </span>
            </button>
          </div>

          <CourseBasicInfo
            v-if="currentStep === 1"
            :form="form"
            :categories="categories"
            :tags="tags"
          />

          <CourseChapters
            v-if="currentStep === 2"
            :form="form"
            :course-id="course.id"
          />

          <CourseSlides
            v-if="currentStep === 3"
            :form="form"
            :course-id="course.id"
            :total-slides="totalSlides"
            :course-hashid="course.hashid"
          />

          <CoursePlan
            v-if="currentStep === 4"
            :form="form"
            :course-id="course.id"
            :course-hashid="course.hashid"
          />

          <CourseReview
            v-if="currentStep === 5"
            :form="form"
            :selected-category="selectedCategory"
            :total-slides="totalSlides"
            :course-id="course.id"
          />

          <div class="builder-footer">
            <BButton
              type="button"
              variant="light"
              class="footer-btn"
              :disabled="isFirstStep"
              @click="previousStep"
            >
              <i class="ri-arrow-left-line me-1"></i>
              Previous
            </BButton>

            <div class="d-flex flex-wrap gap-2 justify-content-end">
              <BButton
                v-if="!isLastStep"
                type="button"
                variant="success"
                class="footer-btn"
                :disabled="form.processing"
                @click="saveCurrentStep(true)"
              >
                <span
                  v-if="form.processing"
                  class="spinner-border spinner-border-sm me-1"
                ></span>
                <i v-else class="ri-save-line me-1"></i>
                Save & Next
              </BButton>

              <BButton
                v-if="!isLastStep"
                type="button"
                variant="primary"
                class="footer-btn"
                @click="nextStep"
              >
                Next
                <i class="ri-arrow-right-line ms-1"></i>
              </BButton>

              <BButton
                v-if="isLastStep"
                type="button"
                variant="success"
                class="footer-btn"
                :disabled="form.processing"
                @click="saveCurrentStep(false)"
              >
                <span
                  v-if="form.processing"
                  class="spinner-border spinner-border-sm me-1"
                ></span>
                <i v-else class="ri-save-line me-1"></i>
                Save Changes
              </BButton>

              <Link
                v-if="isLastStep"
                :href="route('courses.index')"
                class="btn btn-primary footer-btn"
              >
                Finish
                <i class="ri-check-line ms-1"></i>
              </Link>
            </div>
          </div>
        </BCardBody>
      </BCard>
    </div>
  </Layout>
</template>